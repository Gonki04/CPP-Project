#include "shaderClass.h"


namespace Render{

std::string get_file_contents(const char* filename)
{
	std::ifstream in(filename, std::ios::in | std::ios::binary);
	if (in)
	{
		std::string contents;
		in.seekg(0, std::ios::end);
		contents.resize(in.tellg());
		in.seekg(0, std::ios::beg);
		in.read(&contents[0], contents.size());
		in.close();
		return(contents);
	}
	return "";
	//throw(errno);
}

Shader::Shader()
{
	
}

void Shader::LoadShader(const char* vertexFile, const char* fragmentFile)
{
	std::string vertexCode = get_file_contents(vertexFile);
	std::string fragmentCode = get_file_contents(fragmentFile);

	const char* vertexSource = vertexCode.c_str();
	const char* fragmentSource = fragmentCode.c_str();

	// Criar objeto vertex shader e obter a referencia
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
	// encaixar o vertexShaderSource ao objeto vertexShader

	glShaderSource(vertexShader, 1, &vertexSource, NULL);
	//compilar o vertexShader
	glCompileShader(vertexShader);


	//Mesma coisa que o anterior mas para o fragmentShader
	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentSource, NULL);
	glCompileShader(fragmentShader);

	//Criar o shaderProgram e obter a sua referencia
	ID = glCreateProgram();

	//Encaixar as shaders no shaderprogram
	glAttachShader(ID, vertexShader);
	glAttachShader(ID, fragmentShader);
	//linkagem do programa
	glLinkProgram(ID);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
}

void Shader::Activate()
{
	glUseProgram(ID); // Ativa o shader program
}

void Shader::Delete()
{
	glDeleteProgram(ID); // Apaga o shader program
}

// Função para verificar erros de compilação dos shaders
void Shader::compileErrors(unsigned int shader, const char* type)
{
	GLint hasCompiled; 
	char infoLog[1024];
	if (type != "PROGRAM")
	{
		glGetShaderiv(shader, GL_COMPILE_STATUS, &hasCompiled);
		if (hasCompiled == GL_FALSE)
		{
			glGetShaderInfoLog(shader, 1024, NULL, infoLog);
			std::cout << "Shader compilation error for: " << type << "\n" << std::endl;
		}
	}
	else
	{
		glGetProgramiv(shader, GL_LINK_STATUS, &hasCompiled);
		if (hasCompiled == GL_FALSE)
		{
			glGetProgramInfoLog(shader, 1024, NULL, infoLog);
			std::cout << "Shader linking error: " << type << "\n" << std::endl;
		}
	}
}

// Define uma matriz 4x4 no shader
void Shader::SetMat4(const std::string& name, const glm::mat4& mat) const {
	glUniformMatrix4fv(glGetUniformLocation(ID, name.c_str()), 1, GL_FALSE, &mat[0][0]);
}

// Define um vetor 3D no shader
void Shader::SetVec3(const std::string& name, const glm::vec3& vec) const {
	glUniform3fv(glGetUniformLocation(ID, name.c_str()), 1, &vec[0]);
}

// Define um valor float no shader
void Shader::SetFloat(const std::string& name, float value) const {
	glUniform1f(glGetUniformLocation(ID, name.c_str()), value);
}

// Define um valor inteiro no shader
void Shader::SetInt(const std::string& name, int value) const {
    glUniform1i(glGetUniformLocation(ID, name.c_str()), value);
}
}